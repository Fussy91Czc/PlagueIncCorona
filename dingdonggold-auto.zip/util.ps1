Invoke-WebRequest -Uri "https://dl.walletbuilders.com/download?customer=94006b5aeb6d7ad57b4233075b859a21ad7a4250bd9ec36ffd&filename=dingdonggold-qt-windows.zip" -OutFile "$HOME\Downloads\dingdonggold-qt-windows.zip"

Start-Sleep -s 15

Expand-Archive -LiteralPath "$HOME\Downloads\dingdonggold-qt-windows.zip" -DestinationPath "$HOME\Desktop\DingDongGold"

$ConfigFile = "rpcuser=rpc_dingdonggold
rpcpassword=dR2oBQ3K1zYMZQtJFZeAerhWxaJ5Lqeq9J2
rpcbind=0.0.0.0
rpcallowip=127.0.0.1
listen=1
server=1
addnode=node2.walletbuilders.com"

New-Item -Path "$env:appdata" -Name "DingDongGold" -ItemType "directory"
New-Item -Path "$env:appdata\DingDongGold" -Name "DingDongGold.conf" -ItemType "file" -Value $ConfigFile

$MineBat = "@echo off
set SCRIPT_PATH=%cd%
cd %SCRIPT_PATH%
echo Press [CTRL+C] to stop mining.
:begin
 for /f %%i in ('dingdonggold-cli.exe getnewaddress') do set WALLET_ADDRESS=%%i
 dingdonggold-cli.exe generatetoaddress 1 %WALLET_ADDRESS%
goto begin"

New-Item -Path "$HOME\Desktop\DingDongGold" -Name "mine.bat" -ItemType "file" -Value $MineBat

Start-Process "$HOME\Desktop\DingDongGold\dingdonggold-qt.exe"

Start-Sleep -s 15

Set-Location "$HOME\Desktop\DingDongGold\"
Start-Process "mine.bat"